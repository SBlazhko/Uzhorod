class MessangersController < ApplicationController

	def create
		@user = User.find(params[:user_id])
		@message = Messanger.new(message_params)
		@message.receiver_id = @user.id
		@message.sender_id = current_user.id
		@message.save
		redirect_to user_messangers_path(@user)
	end

	def destroy
		@user = User.find(params[:user_id])
		@user.message.delete_at
		redirect_to user_messangers_path(@user)
	end

	def index
		@user = User.find(params[:user_id])
		@mess= Messanger.new
		@messages = Messanger.where('(receiver_id = ? and sender_id = ?) or (receiver_id = ? and sender_id = ?)',
		current_user.id, @user.id,  @user.id, current_user.id).page(params[:page]).per(5).reverse_order!
	end

	def maillist 
		@users = current_user.received_ms.map(&:sender) + current_user.send_ms.map(&:receiver)
		@users = @users.uniq
	end

	def destroy
		message = Messanger.find(params[:id])
		message.destroy
		redirect_to :back
	end

	def restore
		message = Messanger.with_deleted.find(params[:id])
		message.restore
		redirect_to :back
	end

	private

	def message_params
		params.require(:messanger).permit(:message)
	end
end
