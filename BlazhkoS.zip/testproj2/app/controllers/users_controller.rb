class UsersController < ApplicationController

	def show 
		@user = User.find(params[:id])
		@message = Messanger.new
	end

	def index
		if current_user
			if params[:text].present? 
				it = User.solr_search do
					 fulltext(params[:text]) if params[:text].present?
				end
				@users = it.results
			else
				@users = User.all.page(params[:page]).per(5)
			end
		else
			redirect_to new_user_session_path
		end
	end
end