class ApplicationController < ActionController::Base
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  protect_from_forgery with: :exception
  skip_before_filter :verify_authenticity_token  
  # before_action :authenticate_user!

  before_action :configure_permitted_params, if: :devise_controller?
  before_filter :set_paper_trail_whodunnit
  
  protected

    def configure_permitted_params
      devise_parameter_sanitizer.permit(:account_update, keys: [:avatar, :adress, :date_of_birth, :phone_number])
    end

    def user_for_paper_trail
      admin_user_signed_in? ? current_admin_user.try(:id) : 'Unknown user'
    end
end
