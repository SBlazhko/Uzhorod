class Api::UsersController < ApplicationController
	# http_basic_authenticate_with :email => "test@ukr.net", :password => "111111"

  # skip_before_filter :authenticate_user! # we do not need devise authentication here
  before_filter :fetch_user, :except => [:index, :create]
  skip_before_filter :verify_authenticity_token  

 def fetch_user
    @user = User.find_by_id(params[:id])
 end

  def index
    @users = User.all
    respond_to do |format|
      format.json { render json: @users }
    end
  end

  def create
    @user = User.new(user_api_params	)
    # @user.password = Devise.friendly_token
    respond_to do |format|
      if @user.save
        format.json { render json: @user, status: :created }
      else
        format.json { render json: @user.errors, status: :unprocessable_entity }
      end
    end
  end

  def show
  	# @user = User.find(params[:id])
    respond_to do |format|
      format.json { render json: @user }
    end
  end

  def update
    respond_to do |format|
    	if @user.valid_password?(params[:user][:confirm])
      if @user.update_attributes(user_params)
        format.json { render json: @user, status: :ok }
      else
        format.json { render json: @user.errors, status: :unprocessable_entity }
      end
  else
  	format.json { render text: "Incorrect password"}
   end
  end

  def destroy
    respond_to do |format|
      if @user.destroy
        format.json { render text: "User destroyed", status: :ok }
      else
        format.json { render json: @user.errors, status: :unprocessable_entity }
      end
    end
  end

	private

	def user_api_params
		params.require(:user).permit(:email, :password)
	end
end
