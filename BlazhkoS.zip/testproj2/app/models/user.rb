class User < ActiveRecord::Base
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable, :omniauthable,
         :recoverable, :rememberable, :trackable, :validatable, :omniauth_providers => [:google_oauth2, :facebook]

  has_attached_file :avatar, styles: { medium: "300x300>", thumb: "100x100>" }, default_url: "/index.jpeg"
  validates_attachment_content_type :avatar, content_type: /\Aimage\/.*\Z/

  has_many :received_ms, class_name: 'Messanger', foreign_key: 'receiver_id'
  has_many :send_ms, class_name: 'Messanger', foreign_key: 'sender_id'

  before_save :calculate_age

  has_paper_trail
  
  searchable do
    text :age, :email, :address, :phone_number
    integer :age
    integer :phone_number
  end

private

def calculate_age
    if self.date_of_birth
      now = Time.now.utc.to_date
      self.age = now.year - self.date_of_birth.year - (self.date_of_birth.to_date.change(year: now.year) > now ? 1 : 0)
    end
  end	

def self.to_csv
    CSV.generate do |csv|
      csv << column_names
      User.all.each do |user|
        csv << user.attributes.values_at(*column_names)
      end
    end
  end
  
  # def self.to_xls(options = {})
  #     {
  #         "Id" => id.to_s,
  #         "email" => email,
  #         "adress" => address,
  #         "date_of_birth" => date_of_birth,
  #         "age" => age,
  #         "Phone" => phone_number,
  #         "joined" => created_at
  #     }
  # end
end
