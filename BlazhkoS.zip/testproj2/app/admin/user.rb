ActiveAdmin.register User do

# See permitted parameters documentation:
# https://github.com/activeadmin/activeadmin/blob/master/docs/2-resource-customization.md#setting-up-strong-parameters
#
# permit_params :list, :of, :attributes, :on, :model
#
# or
#
# permit_params do
#   permitted = [:permitted, :attributes]
#   permitted << :other if params[:action] == 'create' && current_user.admin?
#   permitted
# end
permit_params :email, :age, :address, :phone_number

	filter :age
	filter :country

	actions :all, except: [:new,:edit, :destroy]

	before_filter only: [:show, :edit, :update] do
		@user = User.find(params[:id])
	end

	action_item do
		link_to 'Export_to_csv', export_csv_admin_users_path
	end

	action_item do
		link_to 'Export_to_xls', export_xls_admin_users_path
	end

	collection_action :export_csv do 
		@users = User.all
		send_data @users.to_csv, content_type: 'text/csv', filename: 'users.csv'
	end

	collection_action :export_xls do 
		@users = User.all
		send_data @users.to_xls, content_type: 'application/vnd.ms-excel', filename: 'users.xls' 
	end

	action_item do
		link_to 'To site', root_path
	end

	action_item only: :show do
		link_to 'History', history_admin_user_path
	end

	member_action :restore_version, method: :post do
		@user = User.find(params[:id])
		version = @user.versions.find_by_id(params[:version_id])
		# binding.pry
		@user = version.reify.save
		redirect_to admin_users_path
	end

	member_action :history, only: :show do
    @user = User.find(params[:id])
    @versions = @user.versions
    render "layouts/history" #json: @versions #"layouts/history"
  end

	index do
    	id_column
    	column :email
    	column :adress
   		column :age
   		column :phone_number
    	actions 
	end

	controller do
  def show
      @user = User.includes(versions: :item).find(params[:id])
      @versions = @user.versions 
      @user = @user.versions[params[:version].to_i].reify if params[:version]
      show! #it seems to need this
  end
end
  sidebar :versionate, :partial => "layouts/version", :only => :show

	show do
		attributes_table do
			row :email
			row :age
			row :adress
			row :phone_number
			row :avatar do
				image_tag user.avatar.url(:medium)
			end
			user.send_ms.with_deleted.each do |msg|
				row :message do
					msg.message
				end
				if msg.deleted_at
          row ' ' do
            link_to 'Restore', restore_path(msg.sender, msg), method: :post
          end
        else
          row ' ' do
            link_to 'Destroy', user_messanger_path(msg.sender, msg.id), method: :delete, data: { confirm: 'Are you sure?' }
          end
        end
			end
		end
	end
  
	form do |f|
		f.inputs do
		f.input :email
		f.input :age
		f.input :phone_number
		f.input :adress
	end
	f.actions
end
	
end
