require 'test_helper'

class MessangerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
