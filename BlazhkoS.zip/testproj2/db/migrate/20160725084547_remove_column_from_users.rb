class RemoveColumnFromUsers < ActiveRecord::Migration
  def change
    remove_column :users, :slug, :string
    remove_column :users, :country, :string
    remove_column :users, :first_name, :string
    remove_column :users, :last_name, :string
  end
end
