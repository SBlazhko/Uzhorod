class AddColumnToUsers < ActiveRecord::Migration
  def change
    add_column :users, :phone_number, :integer
    add_column :users, :adress, :string
    add_column :users, :date_of_birth, :date
  end
end
