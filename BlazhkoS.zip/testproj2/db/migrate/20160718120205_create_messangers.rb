class CreateMessangers < ActiveRecord::Migration
  def change
    create_table :messangers do |t|
      t.string :message
      t.integer :receiver_id
      t.integer :sender_id

      t.timestamps null: false
    end
  end
end
