class AddDeletedAtToMessangers < ActiveRecord::Migration
  def change
    add_column :messangers, :deleted_at, :datetime
    add_index :messangers, :deleted_at
  end
end
